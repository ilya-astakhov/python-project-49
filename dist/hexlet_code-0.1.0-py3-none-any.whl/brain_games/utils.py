import random


def generate_rand_num(start=2, end=20):
    return random.randint(start, end)
