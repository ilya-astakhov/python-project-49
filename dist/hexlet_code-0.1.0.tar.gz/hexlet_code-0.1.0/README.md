### Hexlet tests and linter status:
[![Actions Status](https://github.com/ilya-astakhov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ilya-astakhov/python-project-49/actions)

<a href="https://codeclimate.com/github/ilya-astakhov/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/475a81d793917967648f/test_coverage" /></a>

<a href="https://codeclimate.com/github/ilya-astakhov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/475a81d793917967648f/maintainability" /></a>

### Аскинема brain-calc:
(https://asciinema.org/a/pdQSXaow3xlim7N5uL6sWvBWC)


### Аскинема brain-even:
(https://asciinema.org/a/JAcjunx0A6BqyWlfvpZmxQddD)


### Аскинема brain-progression:
(https://asciinema.org/a/ACRnFdd4qmVWt9lKweofz7EGz)


### Аскинема brain-prime:
(https://asciinema.org/a/cUcbZ8vutUGRU1YTwlK6GsibB)


### Аскинема brain-gcd:
(https://asciinema.org/a/eCswv8ZIjobEYty35gsNNfAq5)

### инструкцию по сборке и установке пакета:
### Команда build, выполняет poetry build
### Команда publish, выполняет poetry publish --dry-run
### Команда package-install, выполняет python3 -m pip install --user dist/*.whl

### инструкцию по запуску линтера:
### Команда make lint, запускает линтер: poetry run flake8 brain_games

### краткое описание каждой игры:
### brain-even:
### Суть игры в следующем: пользователю показывается случайное число. И ему нужно ответить yes, если число чётное, или no — если нечётное
### brain-calc:
### Суть игры в следующем: пользователю показывается случайное математическое выражение, например, 35 + 16, которое нужно вычислить и записать правильный ответ.
### brain-gcd:
### Суть игры в следующем: пользователю показывается два случайных числа, например, 25 50. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел.
### brain-progression:
### Показываем игроку ряд чисел, который образует арифметическую прогрессию, заменив любое из чисел двумя точками. Игрок должен определить это число.
### brain-prime:
### Пользователь должен определить простое ли число показывает программа


### краткое описание проекта:
### 5 математических игр
